#include <iostream>
using namespace std;
int main()
{
    
//Defining values and calculations

    int level_one_minutes= 78;
    int level_two_minutes= 144;
    
    int level_one_hours= level_one_minutes/ 60;
    int level_two_hours= level_two_minutes/ 60;
    
    int level_one_minutes1=level_one_minutes % 60;
    int level_two_minutes1=level_two_minutes % 60;
    
    int difference_minutes=level_two_minutes-level_one_minutes;
    int difference_hours = difference_minutes / 60;
    int difference_remaining_minutes = difference_minutes % 60;


//Demonstrating results and labels

    cout <<"It took the player "<<level_one_hours<<" hour and "<< level_one_minutes1<< " minutes to complete the level"<< endl;
    cout <<"It took the player "<<level_two_hours<<" hours and "<< level_two_minutes1<< " minutes to complete the level"<< endl;
    cout << "The difference in minutes that it took the player between Level 1 and 2 is " << difference_minutes << " minutes \n Or "<< difference_hours << " hour and " << difference_remaining_minutes << " minutes"<< endl;

    return 0;
}